package library;

/**
 * Class that represents a user of a library.
 */
public class Patron
{
  // details not needed for this exercise...
}
