package api;

/**
 * Represent the 4 possible directions that a lizard can move.
 */
public enum Direction {
	UP, DOWN, RIGHT, LEFT;
}
