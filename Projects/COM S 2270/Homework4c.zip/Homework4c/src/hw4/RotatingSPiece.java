package hw4;

import api.Cell;
import api.Icon;
import api.Position;

public class RotatingSPiece extends AbstractPiece {

    /**
     * Constructs a RotatingSPiece with a specified position and icons.
     *
     * @param position the initial position of the piece
     * @param icons    the icons for the cells of the piece
     * @throws IllegalArgumentException if the icons array is not of length 4
     */
    public RotatingSPiece(Position position, Icon[] icons) {
        super(position);
        if (icons.length != 4) {
            throw new IllegalArgumentException("RotatingSPiece requires exactly 4 icons.");
        }

        // Initialize cells in S-shape
        Cell[] cells = new Cell[] {
            new Cell(icons[0], new Position(0, 0)),
            new Cell(icons[1], new Position(0, 1)),
            new Cell(icons[2], new Position(1, 1)),
            new Cell(icons[3], new Position(1, 2))
        };
        setCells(cells);
    }

    /**
     * Rotates the piece 90° clockwise.
     */
    @Override
    public void transform() {
        for (Cell cell : getCells()) {
            Position oldPos = new Position(cell.getRow(), cell.getCol());
            int newRow = oldPos.col();        // Row becomes column
            int newCol = 2 - oldPos.row();    // Flip row across horizontal centerline
            cell.setPosition(new Position(newRow, newCol));
        }
    }
}
