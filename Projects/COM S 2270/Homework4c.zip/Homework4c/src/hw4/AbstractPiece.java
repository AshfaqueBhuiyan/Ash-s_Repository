package hw4;

import api.Cell;
import api.Icon;
import api.Piece;
import api.Position;

/**
 * Abstract superclass for implementations of the Piece interface.
 */
public abstract class AbstractPiece implements Piece {

  /**
   * Position of this Piece
   */
  private Position position;

  /**
   * Cells of this Piece
   */
  private Cell[] cells;

  /**
   * Constructs a piece with the given position.
   * Subclasses extending this class MUST call setCells to initialize
   * initial cell positions and icons.
   * @param position initial position for upper-left corner of bounding box
   */
  protected AbstractPiece(Position position) {
    this.position = position;
  }

  /**
   * Sets the cells for this piece.
   * @param cells array of cells
   */
  public void setCells(Cell[] cells) {
    if (cells == null || cells.length == 0) {
      throw new IllegalArgumentException("Cells array cannot be null or empty.");
    }
    this.cells = cells;
  }

  /**
   * Returns the cells of the piece relative to its bounding box.
   * @return array of cells
   */
  @Override
  public Cell[] getCells() {
    return cells;
  }

  /**
   * Returns the absolute positions of the cells in the grid.
   * @return array of cells with absolute positions
   */
  @Override
  public Cell[] getCellsAbsolute() {
    Cell[] absoluteCells = new Cell[cells.length];
    for (int i = 0; i < cells.length; i++) {
      Cell c = cells[i];
      Position absolutePos = new Position(
          position.row() + c.getRow(),
          position.col() + c.getCol()
      );
      absoluteCells[i] = new Cell(c.getIcon(), absolutePos);
    }
    return absoluteCells;
  }

  /**
   * Shifts the piece left by one column.
   */
  @Override
  public void shiftLeft() {
    position = new Position(position.row(), position.col() - 1);
  }

  /**
   * Shifts the piece right by one column.
   */
  @Override
  public void shiftRight() {
    position = new Position(position.row(), position.col() + 1);
  }

  /**
   * Moves the piece down by one row.
   */
  @Override
  public void shiftDown() {
    position = new Position(position.row() + 1, position.col());
  }

  /**
   * Cycles the icons within the piece.
   */
  @Override
  public void cycle() {
    if (cells.length > 1) {
      Icon firstIcon = cells[0].getIcon();
      for (int i = 0; i < cells.length - 1; i++) {
        cells[i].setIcon(cells[i + 1].getIcon());
      }
      cells[cells.length - 1].setIcon(firstIcon);
    }
  }
  
  @Override
  public Position getPosition() {
      return position;
  }


  @Override
  public Piece clone() {
    try {
      AbstractPiece s = (AbstractPiece) super.clone();
      s.cells = new Cell[cells.length];
      for (int i = 0; i < cells.length; ++i) {
        s.cells[i] = new Cell(cells[i]);
      }
      return s;
    } catch (CloneNotSupportedException e) {
      return null;  // Can't happen
    }
  }
}