package hw4;

import api.Cell;
import api.Icon;
import api.Position;

public class CirclingPiece extends AbstractPiece {

    /**
     * Constructs a CirclingPiece with a specified position and icons.
     *
     * @param position the initial position of the piece
     * @param icons    the icons for the cells of the piece
     * @throws IllegalArgumentException if the icons array is not of length 4
     */
    public CirclingPiece(Position position, Icon[] icons) {
        super(position);
        if (icons.length != 4) {
            throw new IllegalArgumentException("CirclingPiece requires exactly 4 icons.");
        }

        // Initialize cells along the bounding box perimeter
        Cell[] cells = new Cell[] {
            new Cell(icons[0], new Position(0, 0)), // Top-left
            new Cell(icons[1], new Position(1, 0)), // Middle-left
            new Cell(icons[2], new Position(2, 0)), // Bottom-left
            new Cell(icons[3], new Position(2, 1))  // Bottom-middle
        };
        setCells(cells);
    }

    /**
     * Moves the cells clockwise along the edges of the bounding box.
     */
    @Override
    public void transform() {
        for (Cell cell : getCells()) {
            Position oldPos = new Position(cell.getRow(), cell.getCol());
            int row = oldPos.row();
            int col = oldPos.col();

            // Determine next position clockwise along the bounding box
            if (row == 0 && col < 2) col++; // Move right along the top
            else if (col == 2 && row < 2) row++; // Move down along the right
            else if (row == 2 && col > 0) col--; // Move left along the bottom
            else if (col == 0 && row > 0) row--; // Move up along the left

            cell.setPosition(new Position(row, col));
        }
    }
}
