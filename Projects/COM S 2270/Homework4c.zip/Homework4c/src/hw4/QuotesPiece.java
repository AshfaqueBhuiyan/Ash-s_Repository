package hw4;

import api.Cell;
import api.Icon;
import api.Position;

/**
 * Represents a Quotes-shaped game piece.
 */
public class QuotesPiece extends AbstractPiece {

  /**
   * Constructs a QuotesPiece with a specified position and icons.
   * 
   * @param position the initial position of the piece
   * @param icons    the icons for the cells of the piece
   * @throws IllegalArgumentException if the icons array is not of length 4
   */
  public QuotesPiece(Position position, Icon[] icons) {
    super(position);
    if (icons.length != 4) {
      throw new IllegalArgumentException("QuotesPiece requires exactly 4 icons.");
    }

    // Initialize cells in quotes shape
    Cell[] cells = new Cell[] {
        new Cell(icons[0], new Position(0, 0)), // Top-left
        new Cell(icons[1], new Position(1, 0)), // Middle-left
        new Cell(icons[2], new Position(0, 2)), // Top-right
        new Cell(icons[3], new Position(1, 2))  // Middle-right
    };
    setCells(cells);
  }

  /**
   * Rotates the QuotesPiece clockwise by 90 degrees.
   */
  @Override
  public void transform() {
    for (Cell cell : getCells()) {
      Position oldPos = new Position(cell.getRow(), cell.getCol());
      int newRow = oldPos.col();
      int newCol = 2 - oldPos.row();
      cell.setPosition(new Position(newRow, newCol));
    }
  }
}
