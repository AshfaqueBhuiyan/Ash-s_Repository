package hw4;

import api.Cell;
import api.Icon;
import api.Position;

public class SnakingPiece extends AbstractPiece {

    private static final Position[] SEQUENCE = {
        new Position(0, 0), new Position(0, 1), new Position(0, 2),
        new Position(1, 2), new Position(2, 2), new Position(2, 1),
        new Position(2, 0), new Position(1, 0), new Position(1, 1),
        new Position(1, 2), new Position(1, 1), new Position(1, 0)
    };

    private int state = 0; // Tracks the current state index

    /**
     * Constructs a SnakingPiece with a specified position and icons.
     *
     * @param position the initial position of the piece
     * @param icons    the icons for the cells of the piece
     * @throws IllegalArgumentException if the icons array is not of length 4
     */
    public SnakingPiece(Position position, Icon[] icons) {
        super(position);
        if (icons.length != 4) {
            throw new IllegalArgumentException("SnakingPiece requires exactly 4 icons.");
        }

        // Initialize cells in initial positions
        Cell[] cells = new Cell[] {
            new Cell(icons[0], SEQUENCE[0]),
            new Cell(icons[1], SEQUENCE[1]),
            new Cell(icons[2], SEQUENCE[2]),
            new Cell(icons[3], SEQUENCE[3])
        };
        setCells(cells);
    }

    /**
     * Moves the cells to the next state in the figure-eight pattern.
     */
    @Override
    public void transform() {
        state = (state + 1) % SEQUENCE.length; // Advance to the next state
        Cell[] cells = getCells();
        for (int i = 0; i < cells.length; i++) {
            int index = (state + i) % SEQUENCE.length; // Wrap around sequence index
            cells[i].setPosition(SEQUENCE[index]);
        }
    }
}
