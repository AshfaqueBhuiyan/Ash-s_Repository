package hw4;

import api.Cell;
import api.Position;
/**
 * @author Christian Salazar
 */
public class AAA extends AbstractPiece {
	
	protected AAA(Position position) {
		super(position);
		// TODO Auto-generated constructor stub
	}

	@Override
	//Vertical transformation
	public void transform() {
		Cell[] cells = getCells();

		for (Cell cell : cells) {
			//Object cell iterates through list of cells, but the logic only allows for the head cell
			
			// column to be transformed.
			int newCol = 2 - cell.getCol();
			cell.setRowCol(cell.getRow(), newCol);
		}
		setCells(cells);
	}

}
