package hw4;

import api.Position;
/**
 * @author Christian Salazar
 */
public class DDD extends CCC {
	
	//Store Positions for the positions of SnakingPiece's movement
	private static final Position[] snakeSequence = { new Position(0, 0), new Position(0, 1), new Position(0, 2), // --> Along TopRow
													new Position(1, 2), new Position(1, 1), new Position(1, 0), // v, <-- Along MiddleRow
													new Position(2, 0), new Position(2, 1), new Position(2, 2), // v, --> Along BottomRow
													new Position(1, 2), new Position(1, 1), new Position(1, 0)}; // ^, <-- Along MiddleRow, then loop
	/**
	 * Uses original CirclingPiece sequence coordinates and overrides it with snakeSequence coordinates. This way
	 * the transform method doesn't need to be copied over again.
	 * @param position
	 */
	protected DDD(Position position) {
		super(position);
		sequence = snakeSequence;
	}
}
