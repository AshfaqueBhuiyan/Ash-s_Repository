package hw4;

import java.util.ArrayList;

import api.Cell;
import api.Position;
/**
 * @author Christian Salazar
 */
public class CCC extends AbstractPiece {
	//for counting through sequence[]
	int counter = 0;
	
	//storing an array for the positions of CirclingPiece's movement
	protected Position[] sequence = { new Position(0, 0), new Position(0, 1), new Position(0, 2), // --> Along TopRow
													new Position(1, 2), //Middle-Right v
													new Position(2, 2), new Position(2, 1), new Position(2, 0), // <-- Along BottomRow
													new Position(1, 0) }; //Middle-Left ^

	protected CCC(Position position) {
		super(position);
	}
	
	@Override
	public void transform() {
		counter++; //Increment each method call
		Cell[] cells = getCells();
		//To add elements to an expanding array (yes, an array set at 4 could also work)
		ArrayList<Position> oldPositions = new ArrayList<>();
		//Storing old positions
		for (int i = 0; i < cells.length; ++i) {
			oldPositions.add(new Position(cells[i].getRow(), cells[i].getCol()));
		}
		cells[0].setPosition(sequence[counter % sequence.length]); //The head of the cells is the line leader
		
		//Update all cells with previous cell's old positions.
		for (int i = 1; i < cells.length; ++i) {
		cells[i].setPosition(oldPositions.get(i-1));
		}
		setCells(cells);
	}

}
