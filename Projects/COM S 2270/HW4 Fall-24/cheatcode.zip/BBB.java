package hw4;

import api.Cell;
import api.Position;

public class BBB extends AbstractPiece {

	protected BBB(Position position) {
		super(position);
	}
	
	@Override
	//Clockwise Rotation for QuotesPiece and RotatingSPiece
	public void transform() {
		Cell[] cells = getCells();

		for (Cell cell : cells) {
			int newRow = cell.getCol();
			int newCol = 2 - cell.getRow();
			cell.setRowCol(newRow, newCol);
		}
		setCells(cells);
	}
	

}
