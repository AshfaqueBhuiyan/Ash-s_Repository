package ui;

import java.awt.Color;
import java.awt.Dimension;

import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

import api.Game;

/**
 * Main class for a GUI for a Tetris-type game sets up a 
 * GamePanel instance in a frame.  Edit the create() method
 * to change the game or generator type.
 */
public class GameMain
{
  /**
   * Cell size in pixels.
   */
  public static final int SIZE = 25; 
  
  /**
   * Font for displaying score.
   */
  public static final int SCORE_FONT = 24; 
  
  /**
   * Grid background color.
   */
  public static final Color BACKGROUND_COLOR = Color.LIGHT_GRAY;
  
  
  /**
   * Helper method for instantiating the components.  This
   * method should be executed in the context of the Swing
   * event thread only.
   */
  private static void create()
  {
      // Use BlockAddiction with BasicGenerator and a checkerboard fill of 5 rows
      Game game = new hw4.BlockAddiction(20, 12, new hw4.BasicGenerator(), 5);

      // Create the three panels for the game
      PlayLevel level = new PlayLevel();
      ScorePanel scorePanel = new ScorePanel();
      PreviewPanel previewPanel = new PreviewPanel();
      GamePanel gamePanel = new GamePanel(game, scorePanel, previewPanel, level);
       
      // Arrange the three panels with main on bottom, score and preview on top
      JPanel topPanel = new JPanel();
      topPanel.add(scorePanel);
      topPanel.add(previewPanel);
      
      JPanel mainPanel = new JPanel();
      mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
      mainPanel.add(topPanel);
      mainPanel.add(gamePanel);
      
      // Put main panel in a window
      JFrame frame = new JFrame("Com S 2270 Block Addiction!");
      frame.getContentPane().add(mainPanel);

      // Give panels a nonzero size
      int pad = 20;
      Dimension d = new Dimension(game.getWidth() * GameMain.SIZE, game.getHeight() * GameMain.SIZE);   
      gamePanel.setPreferredSize(d);
      d = new Dimension(game.getWidth() * GameMain.SIZE - 3 * GameMain.SIZE - pad, 3 * GameMain.SIZE);   
      scorePanel.setPreferredSize(d);
      d = new Dimension(3 * GameMain.SIZE, 3 * GameMain.SIZE);   
      previewPanel.setPreferredSize(d);
      frame.pack();
      
      // Close the application when the "close" button is pressed
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      
      // Ensure key events get to the panel
      gamePanel.requestFocus();
      
      // Display the window
      frame.setVisible(true);
  }

  
  /**
   * Entry point.  Main thread passed control immediately
   * to the Swing event thread.
   * @param args not used
   */
  public static void main(String[] args)
  {
    Runnable r = new Runnable()
    {
      public void run()
      {
        create();
      }
    };
    SwingUtilities.invokeLater(r);
  }
}
