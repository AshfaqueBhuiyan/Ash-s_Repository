package hw4;

import api.Cell;
import api.Icon;
import api.Piece;
import api.Position;

public abstract class AbstractPiece implements Piece {

    private Position position;
    private Cell[] cells;

    protected AbstractPiece(Position position) {
        this.position = position;
    }

    public void setCells(Cell[] cells) {
        if (cells == null || cells.length == 0) {
            throw new IllegalArgumentException("Cells array cannot be null or empty.");
        }
        this.cells = new Cell[cells.length];
        for (int i = 0; i < cells.length; i++) {
            this.cells[i] = new Cell(cells[i]);
        }
    }

    @Override
    public Position getPosition() {
        return position;
    }

    @Override
    public void shiftLeft() {
        position = new Position(position.row(), position.col() - 1);
    }

    @Override
    public void shiftRight() {
        position = new Position(position.row(), position.col() + 1);
    }

    @Override
    public void shiftDown() {
        position = new Position(position.row() + 1, position.col());
    }

    @Override
    public Cell[] getCells() {
        // Return the actual reference (not a copy)
        return cells;
    }


    @Override
    public Cell[] getCellsAbsolute() {
        Cell[] absoluteCells = new Cell[cells.length];
        for (int i = 0; i < cells.length; i++) {
            Cell c = cells[i];
            Position absolutePos = new Position(
                position.row() + c.getRow(),
                position.col() + c.getCol()
            );
            absoluteCells[i] = new Cell(c.getIcon(), absolutePos);
        }
        return absoluteCells;
    }

    @Override
    public void cycle() {
        if (cells.length <= 1) return;
        Icon firstIcon = cells[0].getIcon();
        for (int i = 0; i < cells.length - 1; i++) {
            cells[i].setIcon(cells[i + 1].getIcon());
        }
        cells[cells.length - 1].setIcon(firstIcon);
    }


    @Override
    public Piece clone() {
        try {
            AbstractPiece cloned = (AbstractPiece) super.clone();
            cloned.cells = new Cell[cells.length];
            for (int i = 0; i < cells.length; i++) {
                cloned.cells[i] = new Cell(new Icon(cells[i].getIcon()), new Position(cells[i].getRow(), cells[i].getCol()));
            }
            return cloned;
        } catch (CloneNotSupportedException e) {
            return null;
        }
    }

}
