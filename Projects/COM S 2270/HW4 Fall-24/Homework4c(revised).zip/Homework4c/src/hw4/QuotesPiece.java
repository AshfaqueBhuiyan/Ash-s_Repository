package hw4;

import api.Cell;
import api.Icon;
import api.Position;

public class QuotesPiece extends AbstractPiece {

    public QuotesPiece(Position position, Icon[] icons) {
        super(position);
        if (icons.length != 4) {
            throw new IllegalArgumentException("QuotesPiece requires exactly 4 icons.");
        }
        Cell[] cells = {
            new Cell(icons[0], new Position(0, 0)),
            new Cell(icons[1], new Position(1, 0)),
            new Cell(icons[2], new Position(0, 2)),
            new Cell(icons[3], new Position(1, 2))
        };
        setCells(cells);
    }

    @Override
    public void transform() {
        for (Cell cell : getCells()) {
            int oldRow = cell.getRow();
            int oldCol = cell.getCol();
            cell.setPosition(new Position(oldCol, 2 - oldRow));
        }
    }
}
