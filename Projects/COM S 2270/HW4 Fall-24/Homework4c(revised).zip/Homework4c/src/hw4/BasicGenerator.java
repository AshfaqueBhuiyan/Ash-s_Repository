package hw4;

import java.util.Random;

import api.Generator;
import api.Icon;
import api.Piece;
import api.Position;

public class BasicGenerator implements Generator
{
    private Random rand;

    /**
     * Constructs a BasicGenerator that will use the given Random object as its source of randomness.
     */
    public BasicGenerator()
    {
        rand = new Random();
    }

    @Override
    public Piece getNext(int width)
    {
        int col = width / 2 - 1;
        int p = rand.nextInt(100);  // Random number between 0 and 99

        // Return different concrete pieces based on probabilities
        if (p < 20)  // 20% chance for LShapedPiece
        {
            return new LShapedPiece(new Position(-1, col), getBlocks(4));
        }
        else if (p < 40)  // 20% chance for TeePiece
        {
            return new TeePiece(new Position(-1, col), getBlocks(4));
        }
        else if (p < 55)  // 15% chance for CirclingPiece
        {
            return new CirclingPiece(new Position(-1, col), getBlocks(4));
        }
        else if (p < 70)  // 15% chance for SnakingPiece
        {
            return new SnakingPiece(new Position(-1, col), getBlocks(4));
        }
        else if (p < 85)  // 15% chance for QuotesPiece
        {
            return new QuotesPiece(new Position(-1, col), getBlocks(4));
        }
        else  // 15% chance for RotatingSPiece
        {
            return new RotatingSPiece(new Position(-1, col), getBlocks(4));
        }
    }

    @Override
    public Icon randomIcon()
    {
        return new Icon(Icon.COLORS[rand.nextInt(Icon.COLORS.length)]);
    }

    /**
     * Generates an array of random icons with the specified length.
     *
     * @param num Number of icons to generate
     * @return Array of random icons
     */
    private Icon[] getBlocks(int num)
    {
        Icon[] icons = new Icon[num];
        for (int i = 0; i < icons.length; i++)
        {
            icons[i] = randomIcon();
        }
        return icons;
    }
}
